# Data-Cleanup-Assignment
=======
When the filtering is done please save your data set as a new file. 

